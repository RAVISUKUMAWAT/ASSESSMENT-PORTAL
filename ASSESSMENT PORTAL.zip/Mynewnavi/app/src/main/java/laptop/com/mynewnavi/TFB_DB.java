package laptop.com.mynewnavi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TFB_DB extends SQLiteOpenHelper {
    public TFB_DB(Context context) {
        super(context, "Webdv", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String tab="CREATE TABLE recordl(id INTEGER PRIMARY KEY AUTOINCREMENT,user VARCHAR ,password VARCHAR)";
        String c = "create table cquestion(id INTEGER PRIMARY KEY AUTOINCREMENT,question varchar(300),optionA varchar(100),optionB varchar(100),optionC varchar(100),optionD varchar(100),answer varchar(100))";
        String cpp = "create table cppquestion(id INTEGER PRIMARY KEY AUTOINCREMENT,question varchar(300),optionA varchar(100),optionB varchar(100),optionC varchar(100),optionD varchar(100),answer varchar(100))";
        String java = "create table javaquestion(id INTEGER PRIMARY KEY AUTOINCREMENT,question varchar(300),optionA varchar(100),optionB varchar(100),optionC varchar(100),optionD varchar(100),answer varchar(100))";
        sqLiteDatabase.execSQL(c);
        sqLiteDatabase.execSQL(cpp);
        sqLiteDatabase.execSQL(java);
        sqLiteDatabase.execSQL(tab);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public void addRecord(String user,String password){

        SQLiteDatabase bd=this.getWritableDatabase();

        ContentValues obj=new ContentValues();

        obj.put("user",user);
        obj.put("password",password);


        bd.insert("recordl",null,obj);
        bd.close();

    }
    public String login(String us){
        String pass=null;

        SQLiteDatabase db=this.getWritableDatabase();

        String loginn="SELECT* FROM recordl WHERE user='"+us+"'";


        Cursor c=db.rawQuery(loginn,null);

        if(c.getCount()==0){

            return pass;
        }
        else if( c.moveToFirst()) {


            pass = c.getString(2);

            return pass;
        }
        else{
            return pass;
        }


    }
    public void addCq(String Q, String oA, String oB, String oC, String oD, String ans) {
        SQLiteDatabase bd = this.getWritableDatabase();

        ContentValues obj = new ContentValues();
        obj.put("question", Q);
        obj.put("optionA", oA);
        obj.put("optionB", oB);
        obj.put("optionC", oC);
        obj.put("optionD", oD);
        obj.put("answer", ans);
        bd.insert("cquestion", null, obj);
        bd.close();
    }


    public void addCppq(String Q, String oA, String oB, String oC, String oD, String ans) {
        SQLiteDatabase bd = this.getWritableDatabase();

        ContentValues obj = new ContentValues();
        obj.put("question", Q);
        obj.put("optionA", oA);
        obj.put("optionB", oB);
        obj.put("optionC", oC);
        obj.put("optionD", oD);
        obj.put("answer", ans);
        bd.insert("cppquestion", null, obj);
        bd.close();
    }

    public void addJavaq(String Q, String oA, String oB, String oC, String oD, String ans) {
        SQLiteDatabase bd = this.getWritableDatabase();

        ContentValues obj = new ContentValues();
        obj.put("question", Q);
        obj.put("optionA", oA);
        obj.put("optionB", oB);
        obj.put("optionC", oC);
        obj.put("optionD", oD);
        obj.put("answer", ans);
        bd.insert("javaquestion", null, obj);
        bd.close();
    }


    public Cursor getCRecord(int id) {
        SQLiteDatabase bd = this.getWritableDatabase();
        Cursor c = null;

        String all = "SELECT question,optionA,optionB,optionC,optionD FROM cquestion Where id = '" + id + "' ";

        c = bd.rawQuery(all, null);


        return c;

    }

    public Cursor getCppRecord(int id) {
        SQLiteDatabase bd = this.getWritableDatabase();
        Cursor c = null;

        String all = "SELECT question,optionA,optionB,optionC,optionD FROM cppquestion Where id = '" + id + "' ";

        c = bd.rawQuery(all, null);


        return c;

    }
    public Cursor getJavaRecord(int id) {
        SQLiteDatabase bd = this.getWritableDatabase();
        Cursor c = null;

        String all = "SELECT question,optionA,optionB,optionC,optionD FROM javaquestion Where id = '" + id + "' ";

        c = bd.rawQuery(all, null);


        return c;

    }
    public String ansC(int id) {
        String ans = null;

        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM cquestion WHERE id='" + id + "'";


        Cursor c = db.rawQuery(loginn, null);

        if (c.getCount() == 0) {

            return ans;
        } else if (c.moveToFirst()) {


            ans = c.getString(6);

            return ans;
        } else {
            return ans;
        }

    }
    public String ansCpp(int id) {
        String ans = null;

        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM cppquestion WHERE id='" + id + "'";


        Cursor c = db.rawQuery(loginn, null);

        if (c.getCount() == 0) {

            return ans;
        } else if (c.moveToFirst()) {


            ans = c.getString(6);

            return ans;
        } else {
            return ans;
        }

    }
    public String ansJava(int id) {
        String ans = null;

        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM javaquestion WHERE id='" + id + "'";


        Cursor c = db.rawQuery(loginn, null);

        if (c.getCount() == 0) {

            return ans;
        } else if (c.moveToFirst()) {


            ans = c.getString(6);

            return ans;
        } else {
            return ans;
        }

    }
    public int getCcount() {
        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM cquestion";


        Cursor c = db.rawQuery(loginn, null);

        return c.getCount();
    }

    public int getCppcount() {
        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM cppquestion";


        Cursor c = db.rawQuery(loginn, null);

        return c.getCount();
    }
    public int getJavacount() {
        SQLiteDatabase db = this.getWritableDatabase();

        String loginn = "SELECT* FROM javaquestion";


        Cursor c = db.rawQuery(loginn, null);

        return c.getCount();
    }


}

