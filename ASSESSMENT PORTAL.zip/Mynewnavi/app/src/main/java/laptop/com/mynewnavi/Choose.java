package laptop.com.mynewnavi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Choose extends AppCompatActivity {

    Button cl,cpl,jl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        cl = (Button)findViewById(R.id.button6);
        cpl = (Button)findViewById(R.id.button7);
        jl = (Button)findViewById(R.id.button8);

        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Choose.this,AddQues.class);
                i.putExtra("k",cl.getText().toString());
                startActivity(i);
            }
        });
        cpl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Choose.this,AddQues.class);
                i.putExtra("k",cpl.getText().toString());
                startActivity(i);
            }
        });
        jl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Choose.this,AddQues.class);
                i.putExtra("k",jl.getText().toString());
                startActivity(i);
            }
        });

    }
}
