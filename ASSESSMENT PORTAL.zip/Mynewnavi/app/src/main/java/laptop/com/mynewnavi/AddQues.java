package laptop.com.mynewnavi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.Hashtable;
import java.util.Map;

public class AddQues extends AppCompatActivity {

    String url="http://sauravvv.com/Ownserver/insertData.php";
    String urll="http://sauravvv.com/Ownserver/insertDataa.php";
    String urlll="http://sauravvv.com/Ownserver/insertDatab.php";

    EditText Q,op1,op2,op3,op4,ansr;
    Button Add;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ques);

        Q = (EditText)findViewById(R.id.q);
        op1 = (EditText)findViewById(R.id.o1);
        op2 = (EditText)findViewById(R.id.o2);
        op3 = (EditText)findViewById(R.id.o3);
        op4 = (EditText)findViewById(R.id.o4);
        ansr = (EditText)findViewById(R.id.ans);
        Add = (Button) findViewById(R.id.enter);



        Intent i1 = getIntent();
        key = i1.getStringExtra("k");

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (key.equals("C")) {
                    sendData();
                }
                if (key.equals("C++")) {
                    sendDataa();
                }
                if (key.equals("Java")) {
                    sendDatab();
                }
            }

            });
            }


            public void sendData() {

                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener <String>() {
                    @Override
                    public void onResponse(String response) {

                        try {

                            JSONObject obj = new JSONObject(response);
                            String s = obj.getString("status");

                            if (s.equals("1")) {
                                cln();

                                Toast.makeText(AddQues.this, "Data Submited..", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(AddQues.this, "Server Error..?", Toast.LENGTH_LONG).show();
                            }


                        } catch (Exception t) {
                            cln();
                            Toast.makeText(AddQues.this, "Server Error..?" + t, Toast.LENGTH_SHORT).show();
                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
                )
                {

                    protected Map <String, String> getParams() {
                        Map <String, String> mp = null;

                        mp = new Hashtable <String, String>();
                        mp.put("Question", Q.getText().toString());
                        mp.put("option1", op1.getText().toString());
                        mp.put("option2", op2.getText().toString());
                        mp.put("option3", op3.getText().toString());
                        mp.put("option4", op4.getText().toString());
                        mp.put("Answer", ansr.getText().toString());


                        return mp;
                    }
                };
                RequestQueue q = Volley.newRequestQueue(AddQues.this);

                q.add(request);
            }

    public void sendDataa() {

        StringRequest request = new StringRequest(Request.Method.POST, urll, new Response.Listener <String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject obj = new JSONObject(response);
                    String s = obj.getString("status");

                    if (s.equals("1")) {
                        cln();

                        Toast.makeText(AddQues.this, "Data Submited..", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(AddQues.this, "Server Error..?", Toast.LENGTH_LONG).show();
                    }


                } catch (Exception t) {
                    cln();
                    Toast.makeText(AddQues.this, "Server Error..?" + t, Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        )
        {

            protected Map <String, String> getParams() {
                Map <String, String> mp = null;

                mp = new Hashtable <String, String>();
                mp.put("Question", Q.getText().toString());
                mp.put("option1", op1.getText().toString());
                mp.put("option2", op2.getText().toString());
                mp.put("option3", op3.getText().toString());
                mp.put("option4", op4.getText().toString());
                mp.put("Answer", ansr.getText().toString());


                return mp;
            }
        };
        RequestQueue q = Volley.newRequestQueue(AddQues.this);

        q.add(request);
    }

    public void sendDatab() {

        StringRequest request = new StringRequest(Request.Method.POST, urlll, new Response.Listener <String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject obj = new JSONObject(response);
                    String s = obj.getString("status");

                    if (s.equals("1")) {
                        cln();

                        Toast.makeText(AddQues.this, "Data Submited..", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(AddQues.this, "Server Error..?", Toast.LENGTH_LONG).show();
                    }


                } catch (Exception t) {
                    cln();
                    Toast.makeText(AddQues.this, "Server Error..?" + t, Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        )
        {

            protected Map <String, String> getParams() {
                Map <String, String> mp = null;

                mp = new Hashtable <String, String>();
                mp.put("Question", Q.getText().toString());
                mp.put("option1", op1.getText().toString());
                mp.put("option2", op2.getText().toString());
                mp.put("option3", op3.getText().toString());
                mp.put("option4", op4.getText().toString());
                mp.put("Answer", ansr.getText().toString());


                return mp;
            }
        };
        RequestQueue q = Volley.newRequestQueue(AddQues.this);

        q.add(request);
    }




    public void cln() {
                Q.setText(null);
                Q.requestFocus();
                op1.setText(null);
                op2.setText(null);
                op3.setText(null);
                op4.setText(null);
                ansr.setText(null);
            }
        }


