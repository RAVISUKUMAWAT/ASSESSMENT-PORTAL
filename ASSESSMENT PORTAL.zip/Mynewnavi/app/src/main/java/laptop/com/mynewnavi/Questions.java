package laptop.com.mynewnavi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Questions extends AppCompatActivity {
    String url = "http://sauravvv.com/Ownserver/getData.php";


    int i = 1;
    String idd;

    ProgressDialog pd;

    RadioGroup rgg;
    RadioButton r1, r2, r3, r4, r5, r;
    TextView tv;
    Button s, sk;
    String key, anskey;

    int marks = 0, last, wqq = 0, rqq = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        rgg = (RadioGroup) findViewById(R.id.rg1);
        r1 = (RadioButton) findViewById(R.id.rb1);
        r2 = (RadioButton) findViewById(R.id.rb2);
        r3 = (RadioButton) findViewById(R.id.rb3);
        r4 = (RadioButton) findViewById(R.id.rb4);
        r5 = (RadioButton) findViewById(R.id.rb5);
        tv = (TextView) findViewById(R.id.txt);
        s = (Button) findViewById(R.id.sub);
        sk = (Button) findViewById(R.id.skp);

        pd=new ProgressDialog(Questions.this);
        getdata();


        r5.setChecked(true);


        r5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r5.isChecked()) {
                    sk.setVisibility(View.VISIBLE);
                    s.setVisibility(View.INVISIBLE);
                }
            }
        });
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r1.isChecked()) {
                    sk.setVisibility(View.INVISIBLE);
                    s.setVisibility(View.VISIBLE);
                }
                anskey = r1.getText().toString();

            }
        });
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r2.isChecked()) {
                    sk.setVisibility(View.INVISIBLE);
                    s.setVisibility(View.VISIBLE);
                }
                anskey = r2.getText().toString();

            }
        });
        r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r3.isChecked()) {
                    sk.setVisibility(View.INVISIBLE);
                    s.setVisibility(View.VISIBLE);
                }
                anskey = r3.getText().toString();


            }
        });
        r4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r4.isChecked()) {
                    sk.setVisibility(View.INVISIBLE);
                    s.setVisibility(View.VISIBLE);
                }
                anskey = r4.getText().toString();


            }
        });

        Intent i1 = getIntent();
        key = i1.getStringExtra("k");


        disPlay(i);


        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                getdata();
                i++;
            }
        });
        sk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(i<=last)
                {

                    i++;
                    disPlay(i);
                }
                else {
                    Intent u = new Intent(Questions.this,Result.class);
                    u.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                    u.putExtra("m",marks);
                    u.putExtra("r",rqq);
                    u.putExtra("w",wqq);
                    startActivity(u);
                }
                clean();


            }
        });
    }

    public void disPlay(int id) {
        if (key.equals("C")) {
            getdata();

        }

        if (key.equals("C++")) {


        }
        if (key.equals("Java")) {


        }
    }


    public void getdata() {
        pd.setMessage("Loading...");
        pd.setCancelable(false);
        pd.show();
        StringRequest st = new StringRequest(Request.Method.POST, "http://sauravvv.com/Ownserver/getData.php", new Response.Listener <String>() {
            @Override
            public void onResponse(String response) {

                // Toast.makeText(Display.this, ""+response, Toast.LENGTH_SHORT).show();

                pd.dismiss();
                quiz(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {

            protected Map <String, String> getParams() {

                Map <String, String> mp = new HashMap <String, String>();

                mp.put("id", String.valueOf(i));

                return mp;
            }
        };

        RequestQueue q = Volley.newRequestQueue(Questions.this);
        q.add(st);

    }


    public void quiz(String res) {


        try {
            JSONObject obj = new JSONObject(res);

            JSONArray arr = obj.getJSONArray("data");
            for (int i = 0; i < arr.length(); i++) {

                JSONObject p = arr.getJSONObject(i);

                tv.setText(p.getString("id") + "." + p.getString("Question"));
                r1.setText(p.getString("option1"));
                r2.setText(p.getString("option2"));
                r3.setText(p.getString("option3"));
                r4.setText(p.getString("option4"));

            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Server Error..?", Toast.LENGTH_SHORT).show();
        }

    }








    public void clean()
    {
        r1.setChecked(false);
        r2.setChecked(false);
        r3.setChecked(false);
        r4.setChecked(false);
        r5.setChecked(false);
    }
}
