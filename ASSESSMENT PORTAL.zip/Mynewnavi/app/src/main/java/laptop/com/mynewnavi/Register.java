package laptop.com.mynewnavi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.Hashtable;
import java.util.Map;

public class Register extends AppCompatActivity {
    String url="http://sauravvv.com/webservice/insertData_without_image.php";

    EditText us,pw,rpw,mb;
    TextView tx1;
    CardView cadv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        cadv=(CardView)findViewById(R.id.cd);

        us=(EditText)findViewById(R.id.editText);
        pw=(EditText)findViewById(R.id.editText2);
        rpw=(EditText)findViewById(R.id.editText3);
        mb=(EditText)findViewById(R.id.editText4);
        tx1=(TextView) findViewById(R.id.bb);
        cadv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendData();
            }
        });

        }
    public void sendData(){

        StringRequest request=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{

                    JSONObject obj=new JSONObject(response);
                    String s=obj.getString("status");

                    if(s.equals("1")){
                        cln();

                        Toast.makeText(Register.this, "Data Submited..", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(Register.this, "Server Error..?", Toast.LENGTH_LONG).show();
                    }




                }catch (Exception t){
                    cln();
                    Toast.makeText(Register.this, "Server Error..?"+t, Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        ){

            protected Map<String,String> getParams(){
                Map<String,String>mp=null;

                mp=new Hashtable<String, String>();
                mp.put("name",us.getText().toString());
                mp.put("email",pw.getText().toString());
                mp.put("contact",rpw.getText().toString());
                mp.put("password",mb.getText().toString());


                return  mp;
            }
        };
        RequestQueue q= Volley.newRequestQueue(Register.this);

        q.add(request);
    }

    public void cln(){
        us.setText(null);
        us.requestFocus();
        pw.setText(null);
        rpw.setText(null);
        mb.setText(null);
    }
}

