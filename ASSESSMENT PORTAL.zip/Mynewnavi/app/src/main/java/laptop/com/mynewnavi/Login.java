package laptop.com.mynewnavi;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONObject;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Login extends AppCompatActivity  {
    String url="http://sauravvv.com/webservice/login.php";

    ProgressDialog pr;
     EditText editTextEmail;
     EditText editTextPassword;
     TextView BtnLogin;
     TextView rr;
    RadioGroup gb;
    RadioButton bt;
    CardView dd,dc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);




        editTextEmail = (EditText) findViewById(R.id.e1);
        editTextPassword = (EditText) findViewById(R.id.e2);
        BtnLogin = (TextView) findViewById(R.id.login);
        rr = (TextView) findViewById(R.id.register);
        gb = (RadioGroup) findViewById(R.id.radio);
        dd=(CardView)findViewById(R.id.cardview);
        dc=(CardView)findViewById(R.id.ca);




        gb.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int myid = gb.getCheckedRadioButtonId();
                bt = (RadioButton) findViewById(myid);
                if (bt.getText().toString().equals("Admin ")) {
                    BtnLogin.setVisibility(View.VISIBLE);
                    rr.setVisibility(View.INVISIBLE);
                } else {
                    BtnLogin.setVisibility(View.VISIBLE);
                    rr.setVisibility(View.VISIBLE);
                }
            }
        });
        dc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, Register.class);
                startActivity(i);
            }
        });
        dd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                int myid = gb.getCheckedRadioButtonId();
                bt = (RadioButton) findViewById(myid);
                if (bt.getText().toString().equals("Admin")) {

                    String email = editTextEmail.getText().toString();
                    String password = editTextPassword.getText().toString();
                    if (email.equals("ravi") && password.equals("12345")) {
                        Intent i = new Intent(Login.this, Choose.class);
                        startActivity(i);

                    }


                }
                if (bt.getText().toString().equals("User")) {

                    loginwithVolley();


                }


            }


        });
    }


    public void loginwithVolley(){

        pr=new ProgressDialog(Login.this);
        pr.setMessage("Please Wait...");
        pr.show();
        StringRequest res=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                takeResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

            protected Map<String,String> getParams(){

                Map<String,String>mp=null;

                mp=new Hashtable<String, String>();

                mp.put("email",editTextEmail.getText().toString());
                mp.put("password",editTextPassword.getText().toString());

                return  mp;
            }


        };

        RequestQueue q= Volley.newRequestQueue(Login.this);

        q.add(res);

    }

    public void takeResponse(String rs){

        try{

            JSONObject obj=new JSONObject(rs);

            String response=obj.getString("status");

            if(response.equals("1")){

                pr.dismiss();
                Intent i=new Intent(Login.this,SelectQues.class);

                startActivity(i);
                cln();
            }
            else{
                pr.dismiss();
                cln();
                Toast.makeText(this, "Invalid User and Password...?", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception t)
        {

        }

    }

    public void cln(){
        editTextEmail.setText(null);
        editTextEmail.setText(null);
        editTextPassword.requestFocus();

    }


}
