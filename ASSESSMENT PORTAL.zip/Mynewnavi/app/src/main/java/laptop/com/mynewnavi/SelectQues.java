package laptop.com.mynewnavi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectQues extends AppCompatActivity {
    Button cl,cpl,jl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_ques);

        cl = (Button)findViewById(R.id.button3);
        cpl = (Button)findViewById(R.id.button4);
        jl = (Button)findViewById(R.id.button5);

        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SelectQues.this,Questions.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                i.putExtra("k", cl.getText().toString());
                startActivity(i);
            }
        });
        cpl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SelectQues.this,Questions.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                i.putExtra("k",cpl.getText().toString());
                startActivity(i);
            }
        });
        jl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SelectQues.this,Questions.class);
                 i.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
               i.putExtra("k",jl.getText().toString());
                startActivity(i);
            }
        });

    }
}

